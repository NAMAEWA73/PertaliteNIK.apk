plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
 id("org.jetbrains.kotlin.plugin.compose")
}
android {
 namespace="id.pertalitenik.app"
 compileSdk=35
 defaultConfig {
  applicationId="id.pertalitenik.app"
  minSdk=24
  targetSdk=35
  versionCode=2
  versionName="2.0"
 }
}
dependencies {
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.activity:activity-compose:1.10.0")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("com.google.mlkit:text-recognition:16.0.1")
 implementation("com.google.firebase:firebase-firestore-ktx:25.1.1")
 implementation("com.google.firebase:firebase-auth-ktx:23.2.0")
}
