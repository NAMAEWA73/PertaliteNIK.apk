package id.pertalitenik.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Bitmap
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : ComponentActivity() {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) openCamera()
            else status.value = "Izin kamera ditolak."
        }

    private val camera =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != RESULT_OK) {
                status.value = "Pengambilan foto dibatalkan."
                return@registerForActivityResult
            }

            val bitmap = result.data?.extras?.get("data") as? Bitmap
            if (bitmap != null) {
                status.value = "Membaca KTP..."
                runOcr(InputImage.fromBitmap(bitmap, 0))
            } else {
                status.value = "Foto tidak tersedia. Silakan coba lagi."
            }
        }

    private val ocrNik = mutableStateOf("")
    private val status = mutableStateOf("Siap. Tekan Scan KTP.")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            Screen()
        }
    }

    private fun startScan() {
        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        if (intent.resolveActivity(packageManager) != null) {
            camera.launch(intent)
        } else {
            status.value = "Aplikasi kamera tidak tersedia."
        }
    }

    private fun runOcr(image: InputImage) {
        recognizer.process(image)
            .addOnSuccessListener { text ->
                val digits = text.text.filter(Char::isDigit)

                // Regex yang benar untuk 16 digit NIK.
                val match = Regex("""\d{16}""").find(digits)

                ocrNik.value = match?.value.orEmpty()

                status.value =
                    if (ocrNik.value.isNotBlank()) {
                        "NIK ditemukan, silakan periksa."
                    } else {
                        "NIK belum terbaca, silakan koreksi manual."
                    }
            }
            .addOnFailureListener { error ->
                status.value = "OCR gagal: ${error.message ?: "kesalahan tidak diketahui"}"
            }
    }

    override fun onDestroy() {
        recognizer.close()
        super.onDestroy()
    }

    @Composable
    private fun Screen() {
        var nik by remember { mutableStateOf("") }
        var nama by remember { mutableStateOf("") }
        var kendaraan by remember { mutableStateOf("") }
        var liter by remember { mutableStateOf("") }

        LaunchedEffect(ocrNik.value) {
            if (ocrNik.value.isNotBlank()) {
                nik = ocrNik.value
            }
        }

        MaterialTheme {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Pertalite NIK") }
                    )
                }
            ) { paddingValues ->

                Column(
                    modifier = Modifier
                        .padding(paddingValues)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    Button(
                        onClick = { startScan() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📷 SCAN / FOTO KTP")
                    }

                    Text(status.value)

                    OutlinedTextField(
                        value = nik,
                        onValueChange = {
                            nik = it.filter(Char::isDigit).take(16)
                        },
                        label = { Text("NIK (16 digit)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = nama,
                        onValueChange = { nama = it },
                        label = { Text("Nama") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = kendaraan,
                        onValueChange = { kendaraan = it },
                        label = { Text("Nomor kendaraan") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = liter,
                        onValueChange = {
                            liter = it.filter { char -> char.isDigit() || char == '.' }
                        },
                        label = { Text("Jumlah Pertalite (liter)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            status.value =
                                if (nik.length == 16 && liter.toDoubleOrNull() != null) {
                                    "Data siap disimpan (mode demo/offline)."
                                } else {
                                    "Periksa NIK dan jumlah liter."
                                }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SIMPAN TRANSAKSI")
                    }
                }
            }
        }
    }
}
