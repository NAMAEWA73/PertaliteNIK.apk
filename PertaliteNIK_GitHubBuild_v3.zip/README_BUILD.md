# Pertalite NIK — Build APK dari HP
1. Buat repository GitHub `PertaliteNIK`.
2. Upload seluruh isi project ini, bukan ZIP sebagai satu file.
3. Pastikan branch `main`.
4. Buka Actions → Build APK → Run workflow.
5. Setelah selesai, buka hasil run dan download artifact `PertaliteNIK-debug-apk`.
6. Ekstrak artifact lalu instal `app-debug.apk`.

Versi ini adalah demo offline. Firebase/cloud dapat ditambahkan setelah `google-services.json` tersedia.
