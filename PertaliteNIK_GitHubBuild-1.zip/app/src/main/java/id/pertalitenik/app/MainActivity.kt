package id.pertalitenik.app
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity: ComponentActivity(){
 private val recognizer by lazy{TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)}
 private val cameraPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)camera()}
 private val camera=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
  val bmp=r.data?.extras?.get("data") as? android.graphics.Bitmap
  if(bmp!=null)ocr(InputImage.fromBitmap(bmp,0))
 }
 private var ocrNik=mutableStateOf("")
 private var status=mutableStateOf("Siap. Tekan Scan KTP.")
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{Screen()}}
 private fun start(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)camera()else cameraPermission.launch(Manifest.permission.CAMERA)}
 private fun camera(){camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))}
 private fun ocr(img:InputImage){recognizer.process(img).addOnSuccessListener{t->
  val digits=t.text.filter(Char::isDigit); val m=Regex("\d{16}").find(digits)
  ocrNik.value=m?.value?:""; status.value=if(ocrNik.value.isNotBlank())"NIK ditemukan, silakan periksa." else "NIK belum terbaca, koreksi manual."
 }.addOnFailureListener{status.value="OCR gagal: ${it.message}"}}
 @Composable fun Screen(){
  var nik by remember{mutableStateOf("")}; var nama by remember{mutableStateOf("")}
  var kendaraan by remember{mutableStateOf("")}; var liter by remember{mutableStateOf("")}
  LaunchedEffect(ocrNik.value){if(ocrNik.value.isNotBlank())nik=ocrNik.value}
  MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("Pertalite NIK")})}){p->
   Column(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Button({start()},Modifier.fillMaxWidth()){Text("📷 SCAN / FOTO KTP")}
    Text(status.value)
    OutlinedTextField(nik,{nik=it.filter(Char::isDigit).take(16)},label={Text("NIK (16 digit)")},Modifier.fillMaxWidth())
    OutlinedTextField(nama,{nama=it},label={Text("Nama")},Modifier.fillMaxWidth())
    OutlinedTextField(kendaraan,{kendaraan=it},label={Text("Nomor kendaraan")},Modifier.fillMaxWidth())
    OutlinedTextField(liter,{liter=it},label={Text("Jumlah Pertalite (liter)")},Modifier.fillMaxWidth())
    Button({status.value=if(nik.length==16 && liter.toDoubleOrNull()!=null)"Data siap disimpan (mode demo/offline)." else "Periksa NIK dan jumlah liter."},Modifier.fillMaxWidth()){Text("SIMPAN TRANSAKSI")}
   }
  }}
 }
}
